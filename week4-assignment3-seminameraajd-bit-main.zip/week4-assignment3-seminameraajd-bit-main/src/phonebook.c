#include <cs50.h>
#include <stdio.h>
#include <string.h>

// 1. Create a struct Person
typedef struct
{
    string name;
    string phone;
}
person;

int main(void)
{
    // 2. Create an array of persons
    person people[3];

    people[0].name = "Carter";
    people[0].phone = "+1-617-495-1000";

    people[1].name = "David";
    people[1].phone = "+1-617-495-1000";

    people[2].name = "John";
    people[2].phone = "+1-949-468-2750";

    // 3. Ask the user for a name
    string name = get_string("Name: ");

    // 4. Search the array
    for (int i = 0; i < 3; i++)
    {
        // Use strcmp to find the match
        if (strcmp(people[i].name, name) == 0)
        {
            printf("Found %s\n", people[i].phone);
            return 0;
        }
    }

    // 5. If not found
    printf("Not found\n");
    return 1;
}
