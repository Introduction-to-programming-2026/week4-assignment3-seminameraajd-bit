#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int n;

    // 1. & 2. Ask user for a positive integer; re-ask if n < 1
    do
    {
        n = get_int("Height: ");
    }
    while (n < 1);

    // 3. Print a half-pyramid
    // Outer loop for each row
    for (int i = 0; i < n; i++)
    {
        // Inner loop for each column in the current row
        // Row 0 gets 1 hash, Row 1 gets 2 hashes, etc.
        for (int j = 0; j <= i; j++)
        {
            printf("#");
        }

        // Move to the next line after finishing a row
        printf("\n");
    }
}
