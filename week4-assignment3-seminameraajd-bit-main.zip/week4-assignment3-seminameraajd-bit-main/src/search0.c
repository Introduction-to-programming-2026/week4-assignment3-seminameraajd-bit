#include <cs50.h>
#include <stdio.h>

int main(void)
{
    // 1. Create an array of integers
    int numbers[] = {20, 500, 10, 5, 100, 1, 50};

    // 2. Ask the user for a number
    int n = get_int("Number: ");

    // 3. Search the array manually using a loop
    // We use sizeof to determine the number of elements (7 in this case)
    for (int i = 0; i < 7; i++)
    {
        if (numbers[i] == n)
        {
            // 4. If found, print "Found" and exit
            printf("Found\n");
            return 0;
        }
    }

    // If the loop finishes, the number was not in the array
    printf("Not found\n");
    return 1;
}