#include <cs50.h>
#include <stdio.h>

void draw(int n);

int main(void)
{
    // 1. Get height of pyramid from user
    int height = get_int("Height: ");

    // Call the recursive function
    draw(height);
}

void draw(int n)
{
    // 3. Base case: If height is 0 or less, nothing to draw
    if (n <= 0)
    {
        return;
    }

    // 2. Recursive step: Draw a pyramid of height n - 1
    draw(n - 1);

    // Print the n-th row (n hashes)
    for (int i = 0; i < n; i++)
    {
        printf("#");
    }
    printf("\n");
}
