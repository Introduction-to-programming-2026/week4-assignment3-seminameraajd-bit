#include <cs50.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    // 1. Create an array of strings
    string names[] = {"Bill", "Charlie", "Fred", "George", "Ginny", "Percy", "Ron"};

    // 2. Ask the user for a name
    string s = get_string("Name: ");

    // 3. Search the array
    for (int i = 0; i < 7; i++)
    {
        // 4. Use strcmp() to compare strings
        // strcmp returns 0 if the strings are the same
        if (strcmp(names[i], s) == 0)
        {
            // 5. Print Found and exit the program
            printf("Found\n");
            return 0;
        }
    }

    // If the loop finishes without returning, the name wasn't there
    printf("Not found\n");
    return 1;
}